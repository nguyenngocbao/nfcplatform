<?php

namespace App\Repos;

class PlatformRepos
{

}