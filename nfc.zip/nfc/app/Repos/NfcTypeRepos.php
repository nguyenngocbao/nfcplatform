<?php

namespace App\Repos;

class NfcTypeRepos
{

}